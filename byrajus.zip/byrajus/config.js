// ===== config.js =====
module.exports = {
  SERVER: {
    PORT: 5000,
    WEB_NAME: "Virgo Web by Rajukingz",
    AUDIO: "/assets/raju.mp3"
  },
  TELEGRAM: {
    BOT_TOKEN: "8232694593:AAEpUe-V9e-L_9YwRs0ZXYRVMEizOzAknME", // ganti dengan token bot Telegram kamu
    OWNER_ID: 8134760879,          // ganti dengan ID Telegram owner
    GROUP_USERNAME: "+TFwA9kAitwJhZmVl", // invite link grup (tanpa https://t.me/)
    CHANNEL_USERNAME: "rajustoreselaludihati" // username channel publik (tanpa @)
  },
  FILES: {
    LOGIN: "login.json",
    GMAIL: "gmail.json",
    VERIFIED: "verified.json"
  }
};